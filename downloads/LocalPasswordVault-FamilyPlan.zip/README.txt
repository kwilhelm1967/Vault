# Local Password Vault - Family Plan

## Quick Start
1. Install on up to 3 devices using the provided installers
2. Use a different license key for each device (3 keys provided)
3. Create master passwords on each device
4. Set up family sharing in Settings

## Features
- 3 device licenses
- Family password sharing
- Priority support (24 hours)
- All Single User features
- Complete source code included

## What You Get
- Complete React/TypeScript source code
- Pre-built applications for convenience
- All build tools and configuration
- License generator tools
- Full independence - no server dependency
- Working password manager software
- Pre-built applications for all platforms
- Family sharing setup guides
- Full independence - no server dependency

## Support
Email: priority@LocalPasswordVault.com
Response: 24 hours

© 2025 Local Password Vault