# 🔐 Local Password Vault - Single User

## Quick Start
1. Run LocalPasswordVault-Setup.exe (Windows) or LocalPasswordVault.dmg (Mac) or LocalPasswordVault.AppImage (Linux)
2. Enter your license key when prompted
3. Create your master password
4. Start using your password vault!

## Your Purchase
- **Plan:** Single User
- **Price:** $29.00
- **Devices:** 1 device

## Features
✅ Unlimited password storage
✅ AES-256 encryption
✅ Floating panel
✅ Import/Export
✅ Password generator

## Support
Email: support@LocalPasswordVault.com

© 2025 Local Password Vault | LocalPasswordVault.com
