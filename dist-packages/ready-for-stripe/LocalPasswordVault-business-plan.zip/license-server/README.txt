# License Server

Pre-built license server for enterprise deployment.
Run license-server.exe to start.
Configure via config.json.

Enterprise Support: enterprise@LocalPasswordVault.com