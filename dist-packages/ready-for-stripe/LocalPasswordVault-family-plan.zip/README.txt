# 🔐 Local Password Vault - Family Plan

## Quick Start
1. Run LocalPasswordVault-Setup.exe (Windows) or LocalPasswordVault.dmg (Mac) or LocalPasswordVault.AppImage (Linux)
2. Enter your license key when prompted
3. Create your master password
4. Start using your password vault!

## Your Purchase
- **Plan:** Family Plan
- **Price:** $49.00
- **Devices:** 3 devices

## Features
✅ Everything in Single User
✅ 3 device licenses
✅ Family sharing
✅ Priority support (24h)
✅ Secure offline sharing

## Support
Email: priority@LocalPasswordVault.com

© 2025 Local Password Vault | LocalPasswordVault.com
